#ifndef EXCLUIRINFO_ARVORE_BINARIA_H
#define EXCLUIRINFO_ARVORE_BINARIA_H

/* --------------------------*/
pNohPrefixo excluirInfoRecursivo(pNohPrefixo raiz, char chave[], int k, int* L){

}

/* ----------------------------------------------------------*/
int excluirInfo(pDPrefixo arvore, char chave[], int k){


}

#endif
